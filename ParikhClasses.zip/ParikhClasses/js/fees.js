// ===== FEES MODULE =====

function renderFees() {
  const totalFees = state.students.reduce((a,s)=>a+(s.fees||0),0);
  const paidFees = state.students.reduce((a,s)=>a+(s.paid||0),0);
  const pending = totalFees - paidFees;
  const defaulters = state.students.filter(s=>pendingFee(s)>0);

  const feeRows = state.students.map(s => {
    const due = pendingFee(s);
    return `<div class="fee-item">
      <div style="flex:1;min-width:0">
        <div style="font-size:14px;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${s.name}</div>
        <div style="font-size:11px;color:#64748b">${getBatchName(s.batch)} · Std ${s.standard}</div>
      </div>
      <div style="text-align:right;margin-right:8px">
        <div style="font-size:13px;font-weight:600;color:${due>0?'#e02424':'#0e9f6e'}">${due>0?formatCurrency(due)+' due':'✓ Clear'}</div>
        <div style="font-size:11px;color:#64748b">${formatCurrency(s.paid)}/${formatCurrency(s.fees)}</div>
      </div>
      <div style="display:flex;gap:5px">
        <button class="btn-icon btn-fee" onclick="openPayFee(${s.id})" title="Record Payment">💳</button>
        ${due>0?`<button class="btn-icon btn-wa" onclick="sendFeeReminder(${s.id})" title="Fee Reminder">💬</button>`:''}
      </div>
    </div>`;
  }).join('');

  return `
    <div class="stat-grid">
      <div class="stat stat-blue"><div class="stat-val">${formatCurrency(totalFees)}</div><div class="stat-lbl">Total Fees</div></div>
      <div class="stat stat-green"><div class="stat-val">${formatCurrency(paidFees)}</div><div class="stat-lbl">Collected</div></div>
      <div class="stat stat-red"><div class="stat-val">${formatCurrency(pending)}</div><div class="stat-lbl">Pending</div></div>
      <div class="stat stat-amber"><div class="stat-val">${defaulters.length}</div><div class="stat-lbl">Defaulters</div></div>
    </div>
    ${defaulters.length ? `<div class="card" style="border-left:3px solid #e02424">
      <div class="card-title">⚠️ Fee Defaulters</div>
      ${defaulters.map(s=>`<div class="report-row">
        <span style="font-size:13px">${s.name}</span>
        <div style="display:flex;align-items:center;gap:6px">
          <span style="font-size:13px;font-weight:600;color:#e02424">${formatCurrency(pendingFee(s))}</span>
          <button class="btn-icon btn-wa" style="width:28px;height:28px;font-size:13px" onclick="sendFeeReminder(${s.id})" title="Remind">💬</button>
        </div>
      </div>`).join('')}
    </div>` : ''}
    <div class="card">
      <div class="card-title">📋 All Students Fee Status</div>
      ${feeRows || '<div style="color:#94a3b8;font-size:13px">No students added yet</div>'}
    </div>
    <div style="height:10px"></div>
  `;
}

function openPayFee(id) {
  const s = getStudentById(id);
  if (!s) return;
  const due = pendingFee(s);
  showModal(`
    <div class="modal-title">💳 Record Payment</div>
    <div class="card" style="margin-bottom:14px;background:#f8fafc">
      <div style="font-size:16px;font-weight:600">${s.name}</div>
      <div style="font-size:13px;color:#64748b;margin-top:4px">${getBatchName(s.batch)} · ${s.subject}</div>
      <div style="display:flex;gap:12px;margin-top:10px">
        <div><div style="font-size:11px;color:#64748b">Total Fees</div><div style="font-size:15px;font-weight:600">${formatCurrency(s.fees)}</div></div>
        <div><div style="font-size:11px;color:#64748b">Paid</div><div style="font-size:15px;font-weight:600;color:#0e9f6e">${formatCurrency(s.paid)}</div></div>
        <div><div style="font-size:11px;color:#64748b">Pending</div><div style="font-size:15px;font-weight:600;color:#e02424">${formatCurrency(due)}</div></div>
      </div>
    </div>
    <div class="form-group"><label class="form-label">Amount Received (₹) *</label>
      <input class="form-input" id="pay-amount" type="number" placeholder="Enter amount" value="${due||''}" /></div>
    <div class="form-group"><label class="form-label">Payment Mode</label>
      <select class="form-input" id="pay-mode">
        <option>Cash</option><option>UPI / GPay</option><option>PhonePe</option><option>Bank Transfer</option><option>Cheque</option>
      </select>
    </div>
    <div class="form-group"><label class="form-label">Date</label>
      <input class="form-input" id="pay-date" type="date" value="${todayISO()}" /></div>
    <div class="form-group"><label class="form-label">Note (optional)</label>
      <input class="form-input" id="pay-note" placeholder="e.g. First installment" /></div>
    <div class="btn-row">
      <button class="btn btn-secondary" onclick="closeModal()">Cancel</button>
      <button class="btn btn-primary" onclick="recordPayment(${id})">Record & Receipt on WA</button>
    </div>
  `);
}

function recordPayment(id) {
  const s = getStudentById(id);
  if (!s) return;
  const amt = parseInt(document.getElementById('pay-amount')?.value) || 0;
  if (amt <= 0) { showToast('⚠️ Enter valid amount'); return; }
  const mode = document.getElementById('pay-mode')?.value || 'Cash';
  const date = document.getElementById('pay-date')?.value || todayISO();
  const note = document.getElementById('pay-note')?.value || '';
  s.paid = Math.min(s.fees, (s.paid||0) + amt);
  saveData();
  closeModal();
  showToast('✅ Payment recorded!');
  const remaining = pendingFee(s);
  const receiptMsg = `🧾 *Fee Receipt — Parikh Commerce Classes, Nadiad*\n\nStudent: ${s.name}\nRoll No: ${s.rollNo}\nBatch: ${getBatchName(s.batch)}\n\nAmount Paid: ${formatCurrency(amt)}\nPayment Mode: ${mode}\nDate: ${formatDate(date)}\n${note?'Note: '+note+'\n':''}\nTotal Fees: ${formatCurrency(s.fees)}\nTotal Paid: ${formatCurrency(s.paid)}\nBalance Due: ${formatCurrency(remaining)}\n\nThank you! 🙏\n— Parikh Commerce Classes`;

  setTimeout(() => {
    if (confirm(`Send fee receipt to ${s.name} on WhatsApp?`)) {
      window.open(waURL(s.phone, receiptMsg), '_blank');
    }
  }, 300);
}

function sendFeeReminder(id) {
  const s = getStudentById(id);
  if (!s) return;
  const due = pendingFee(s);
  const msg = `Dear ${s.name},\n\n⚠️ Fee Reminder — Parikh Commerce Classes, Nadiad\n\nThis is a gentle reminder that *${formatCurrency(due)}* is due as fees.\n\nTotal Fees: ${formatCurrency(s.fees)}\nPaid: ${formatCurrency(s.paid)}\nDue: ${formatCurrency(due)}\n\nKindly pay at the earliest.\n\nThank you 🙏\n— Parikh Commerce Classes`;
  window.open(waURL(s.phone, msg), '_blank');
}
