// ===== WHATSAPP MODULE =====

const WA_TEMPLATES = {
  welcome: (name, batch, time, subject, roll) =>
`🎉 Welcome to Parikh Commerce Classes, Nadiad!

Dear ${name},

You are now enrolled! 📚
✅ Batch: ${batch}
⏰ Time: ${time}
📖 Subject: ${subject}
🆔 Roll No: ${roll}

We look forward to your bright future! 🌟
— Parikh Commerce Classes`,

  fee_reminder: (name, due, total, paid) =>
`Dear ${name},

⚠️ Fee Reminder — Parikh Commerce Classes

Amount Due: ${formatCurrency(due)}
Total Fees: ${formatCurrency(total)}
Paid: ${formatCurrency(paid)}

Kindly clear your dues at the earliest.
Thank you 🙏
— Parikh Commerce Classes, Nadiad`,

  holiday: (batch) =>
`📢 Notice — Parikh Commerce Classes, Nadiad

Dear Students (${batch}),

Classes are CLOSED tomorrow due to a holiday. 🏖️

Classes will resume as per normal schedule.

Stay safe!
— Parikh Commerce Classes`,

  exam: (batch, subject, date) =>
`📝 Exam Notice — Parikh Commerce Classes

Dear ${batch} Students,

Unit Test is scheduled on ${date}
📚 Subject: ${subject}
Please prepare all chapters.
Bring pen, pencil, and ruler.

All the best! 💪
— Parikh Commerce Classes, Nadiad`,

  result: (batch) =>
`📊 Result Ready — Parikh Commerce Classes

Dear ${batch} Students,

Your test results are ready! 🎯
Please collect your answer sheets from tomorrow's class.

— Parikh Commerce Classes, Nadiad`,

  timetable: (batch, schedule) =>
`📅 Timetable — Parikh Commerce Classes

Dear ${batch} Students,

Updated class schedule:
${schedule}

For queries contact us.
— Parikh Commerce Classes, Nadiad`,

  custom: () => ''
};

function renderWhatsApp() {
  const batchGroups = state.batches.map(b => {
    const count = b.students.length;
    return `<div class="wa-group-btn" onclick="openBatchWA(${b.id})">
      <div class="wa-group-icon">👥</div>
      <div class="wa-group-text">
        <div class="wa-group-name">${b.name}</div>
        <div class="wa-group-sub">${count} students · ${b.waLink ? '✅ Group linked' : '⚠️ Tap to add group link'}</div>
      </div>
      <span style="color:#059669;font-size:18px">▶</span>
    </div>`;
  }).join('');

  const studentList = state.students.slice(0,8).map(s => {
    const av = getAvatarColors(s.name);
    return `<div class="card" style="padding:10px 12px;margin-bottom:8px">
      <div style="display:flex;align-items:center;gap:10px">
        <div class="avatar" style="width:36px;height:36px;font-size:12px;background:${av.bg};color:${av.text}">${getInitials(s.name)}</div>
        <div style="flex:1">
          <div style="font-size:14px;font-weight:600">${s.name}</div>
          <div style="font-size:11px;color:#64748b">${s.phone}</div>
        </div>
        <button class="btn-wa-full" style="width:auto;padding:7px 12px;margin:0;font-size:12px" onclick="sendWAStudent('${s.id}')">💬 Chat</button>
      </div>
    </div>`;
  }).join('');

  return `
    <div class="section-title">📱 Batch WhatsApp Groups</div>
    ${batchGroups || '<div style="color:#94a3b8;font-size:13px">No batches yet</div>'}

    <div class="section-title">📢 Broadcast Message</div>
    <div class="card">
      <div class="form-group">
        <label class="form-label">Select Batch</label>
        <select class="form-input" id="wa-batch">
          <option value="all">All Students</option>
          ${state.batches.map(b=>`<option value="${b.id}">${b.name}</option>`).join('')}
        </select>
      </div>
      <div class="form-group">
        <label class="form-label">Template</label>
        <select class="form-input" id="wa-template" onchange="loadWATemplate(this.value)">
          <option value="">Select template...</option>
          <option value="fee_reminder">💰 Fee Reminder</option>
          <option value="holiday">🏖️ Holiday Notice</option>
          <option value="exam">📝 Exam Notice</option>
          <option value="result">📊 Result Ready</option>
          <option value="timetable">📅 Timetable Update</option>
          <option value="custom">✏️ Custom Message</option>
        </select>
      </div>
      <div class="form-group">
        <label class="form-label">Message</label>
        <textarea class="form-input" id="wa-msg" rows="5" placeholder="Type your message..."></textarea>
      </div>
      <button class="btn-wa-full" onclick="broadcastWA()">💬 Open WhatsApp to Send</button>
      <div style="font-size:11px;color:#94a3b8;margin-top:6px;text-align:center">Opens WhatsApp for the first student. Repeat for each.</div>
    </div>

    <div class="section-title">👤 Individual Messages</div>
    ${studentList}
    ${state.students.length > 8 ? `<div style="text-align:center;font-size:12px;color:#94a3b8;margin-top:4px">+${state.students.length-8} more in Students tab</div>` : ''}
    <div style="height:10px"></div>
  `;
}

function loadWATemplate(type) {
  const msgEl = document.getElementById('wa-msg');
  if (!msgEl || !type) return;
  const batchId = document.getElementById('wa-batch')?.value;
  const batch = batchId !== 'all' ? getBatchById(parseInt(batchId)) : null;
  const batchName = batch ? batch.name : 'All Students';
  const subject = batch ? batch.subject : 'All Subjects';
  const today = new Date().toLocaleDateString('en-IN',{day:'2-digit',month:'short',year:'numeric'});

  const templates = {
    fee_reminder: WA_TEMPLATES.fee_reminder('[Student Name]', 1500, 3000, 1500),
    holiday: WA_TEMPLATES.holiday(batchName),
    exam: WA_TEMPLATES.exam(batchName, subject, today),
    result: WA_TEMPLATES.result(batchName),
    timetable: WA_TEMPLATES.timetable(batchName, 'Mon-Wed-Fri: 4:00 PM - 6:00 PM\nSat: Extra class 10:00 AM'),
    custom: '',
  };
  msgEl.value = templates[type] || '';
}

function broadcastWA() {
  const msg = (document.getElementById('wa-msg')?.value||'').trim();
  if (!msg) { showToast('⚠️ Enter a message first'); return; }
  const batchId = document.getElementById('wa-batch')?.value;
  let studs = batchId === 'all' ? state.students : state.students.filter(s=>s.batch==batchId);
  if (!studs.length) { showToast('⚠️ No students in selected batch'); return; }
  window.open(waURL(studs[0].phone, msg), '_blank');
  if (studs.length > 1) showToast(`Repeat for ${studs.length-1} more students`);
}
