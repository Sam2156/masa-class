// ===== ATTENDANCE MODULE =====

function renderAttendance() {
  const today = todayISO();
  const selBatch = state.attBatch || (state.batches[0]?.id);
  const selDate = state.attDate || today;
  const batch = getBatchById(parseInt(selBatch));
  const studs = batch ? batch.students.map(id=>getStudentById(id)).filter(Boolean) : [];

  const attKey = (studentId, date) => `${studentId}_${date}`;
  const getAtt = (sid, date) => state.attendance[attKey(sid,date)] || 'none';

  const presentCount = studs.filter(s=>getAtt(s.id,selDate)==='present').length;
  const absentCount = studs.filter(s=>getAtt(s.id,selDate)==='absent').length;

  const rows = studs.map((s,i) => {
    const att = getAtt(s.id, selDate);
    const av = getAvatarColors(s.name);
    return `<div class="card" style="padding:10px 14px;margin-bottom:8px">
      <div style="display:flex;align-items:center;gap:10px">
        <div class="avatar" style="width:36px;height:36px;font-size:12px;background:${av.bg};color:${av.text}">${getInitials(s.name)}</div>
        <div style="flex:1">
          <div style="font-size:14px;font-weight:600">${s.name}</div>
          <div style="font-size:11px;color:#64748b">#${s.rollNo}</div>
        </div>
        <div style="display:flex;gap:6px">
          <button class="btn-icon ${att==='present'?'':'btn-del'}" style="${att==='present'?'background:#def7ec;color:#0e9f6e;':''}" onclick="markAtt('${s.id}','${selDate}','present')" title="Present">✓</button>
          <button class="btn-icon ${att==='absent'?'':'btn-del'}" style="${att==='absent'?'background:#fde8e8;color:#e02424;':''}" onclick="markAtt('${s.id}','${selDate}','absent')" title="Absent">✗</button>
        </div>
        <span class="badge ${att==='present'?'badge-green':att==='absent'?'badge-red':'badge-gray'}">${att==='present'?'Present':att==='absent'?'Absent':'—'}</span>
      </div>
    </div>`;
  }).join('');

  return `
    <div style="display:flex;gap:8px;margin-bottom:12px">
      <select class="form-input" style="flex:1" onchange="setAttBatch(this.value)">
        ${state.batches.map(b=>`<option value="${b.id}" ${selBatch==b.id?'selected':''}>${b.name}</option>`).join('')}
      </select>
      <input type="date" class="form-input" style="flex:1" value="${selDate}" onchange="setAttDate(this.value)" />
    </div>
    <div class="stat-grid" style="margin-bottom:12px">
      <div class="stat stat-green"><div class="stat-val">${presentCount}</div><div class="stat-lbl">Present</div></div>
      <div class="stat stat-red"><div class="stat-val">${absentCount}</div><div class="stat-lbl">Absent</div></div>
    </div>
    ${studs.length ? `
      <div style="display:flex;gap:8px;margin-bottom:12px">
        <button class="btn btn-green" style="flex:1;padding:10px" onclick="markAllAtt('${selDate}',${selBatch},'present')">✓ All Present</button>
        <button class="btn btn-danger" style="flex:1;padding:10px" onclick="markAllAtt('${selDate}',${selBatch},'absent')">✗ All Absent</button>
      </div>
      ${rows}
      ${absentCount > 0 ? `<button class="btn-wa-full" onclick="sendAbsentNotices('${selDate}',${selBatch})">💬 Send Absent Notices on WhatsApp</button>` : ''}
    ` : `<div class="empty-state"><div class="empty-icon">👥</div><div class="empty-text">No students in this batch</div></div>`}
    <div style="height:10px"></div>
  `;
}

function setAttBatch(val) { state.attBatch = val; render(); }
function setAttDate(val) { state.attDate = val; render(); }

function markAtt(studentId, date, status) {
  const key = `${studentId}_${date}`;
  const current = state.attendance[key] || 'none';
  state.attendance[key] = current === status ? 'none' : status;
  saveData();
  render();
}

function markAllAtt(date, batchId, status) {
  const batch = getBatchById(parseInt(batchId));
  if (!batch) return;
  batch.students.forEach(sid => {
    state.attendance[`${sid}_${date}`] = status;
  });
  saveData();
  render();
}

function sendAbsentNotices(date, batchId) {
  const batch = getBatchById(parseInt(batchId));
  if (!batch) return;
  const absentStudents = batch.students
    .map(id=>getStudentById(id))
    .filter(s=>s && state.attendance[`${s.id}_${date}`]==='absent');
  if (!absentStudents.length) { showToast('No absent students'); return; }
  const first = absentStudents[0];
  const msg = `Dear ${first.parentName || first.name},\n\n⚠️ Absence Notice — Parikh Commerce Classes\n\n${first.name} was ABSENT from ${getBatchName(parseInt(batchId))} on ${formatDate(date)}.\n\nKindly ensure regular attendance.\n\n— Parikh Commerce Classes, Nadiad`;
  window.open(waURL(first.parentPhone || first.phone, msg), '_blank');
  if (absentStudents.length > 1) showToast(`Open WhatsApp for each of ${absentStudents.length} absent students`);
}
