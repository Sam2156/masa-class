// ===== STUDENTS MODULE =====

function renderStudents() {
  let filtered = state.students.filter(s => {
    const q = (state.searchQ||'').toLowerCase();
    return !q || s.name.toLowerCase().includes(q) || (s.phone||'').includes(q) || (s.rollNo||'').includes(q);
  });
  if (state.filterBatch !== 'all') filtered = filtered.filter(s => s.batch == state.filterBatch);

  const tabs = `<div class="tab-row">
    <span class="tab ${state.filterBatch==='all'?'active':''}" onclick="setBatchFilter('all')">All (${state.students.length})</span>
    ${state.batches.map(b=>`<span class="tab ${state.filterBatch==b.id?'active':''}" onclick="setBatchFilter(${b.id})">${b.name} (${b.students.length})</span>`).join('')}
  </div>`;

  const list = filtered.length ? filtered.map((s,i) => {
    const av = getAvatarColors(s.name);
    const due = pendingFee(s);
    return `<div class="card">
      <div class="student-row">
        <div class="avatar" style="width:42px;height:42px;font-size:14px;background:${av.bg};color:${av.text}">${getInitials(s.name)}</div>
        <div class="student-info">
          <div class="student-name">${s.name} <span style="font-size:11px;color:#94a3b8;font-weight:400">#${s.rollNo||'—'}</span></div>
          <div class="student-meta">Std ${s.standard} · ${getBatchName(s.batch)}</div>
          <div class="student-meta">📱 ${s.phone}</div>
        </div>
        <div class="action-btns">
          <button class="btn-icon btn-wa" onclick="sendWAStudent('${s.id}')" title="WhatsApp">💬</button>
          <button class="btn-icon btn-edit" onclick="openEditStudent(${s.id})" title="Edit">✏️</button>
          <button class="btn-icon btn-del" onclick="deleteStudent(${s.id})" title="Delete">🗑️</button>
        </div>
      </div>
      <div style="display:flex;gap:6px;margin-top:8px;flex-wrap:wrap">
        <span class="badge badge-blue">${s.subject}</span>
        <span class="badge ${due>0?'badge-red':'badge-green'}">${due>0?formatCurrency(due)+' due':'Fees clear ✓'}</span>
        ${s.parentName ? `<span class="badge badge-gray">👨‍👧 ${s.parentName}</span>` : ''}
      </div>
    </div>`;
  }).join('') : `<div class="empty-state"><div class="empty-icon">🔍</div><div class="empty-text">No students found</div></div>`;

  return `
    <div class="search-box">
      <span style="font-size:16px">🔍</span>
      <input type="text" placeholder="Search name, phone, roll no..." value="${state.searchQ||''}" oninput="setSearch(this.value)"/>
    </div>
    ${tabs}
    ${list}
    <div style="height:10px"></div>
  `;
}

function setBatchFilter(v) { state.filterBatch = v; render(); }
function setSearch(v) { state.searchQ = v; render(); }

function studentForm(s) {
  const isEdit = !!s;
  return `
    <div class="form-group"><label class="form-label">Full Name *</label>
      <input class="form-input" id="f-name" placeholder="Student full name" value="${s?s.name:''}" /></div>
    <div class="form-group"><label class="form-label">Phone Number *</label>
      <input class="form-input" id="f-phone" type="tel" placeholder="10-digit mobile" maxlength="10" value="${s?s.phone:''}" /></div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
      <div class="form-group"><label class="form-label">Standard</label>
        <select class="form-input" id="f-std">${STANDARDS.map(st=>`<option value="${st}" ${s&&s.standard===st?'selected':''}>${st}th/FY</option>`)}</select></div>
      <div class="form-group"><label class="form-label">Batch *</label>
        <select class="form-input" id="f-batch">${state.batches.map(b=>`<option value="${b.id}" ${s&&s.batch===b.id?'selected':''}>${b.name}</option>`).join('')}</select></div>
    </div>
    <div class="form-group"><label class="form-label">Subject</label>
      <select class="form-input" id="f-subj">${SUBJECTS.map(sub=>`<option value="${sub}" ${s&&s.subject===sub?'selected':''}>${sub}</option>`).join('')}</select></div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
      <div class="form-group"><label class="form-label">Total Fees (₹)</label>
        <input class="form-input" id="f-fees" type="number" placeholder="e.g. 3000" value="${s?s.fees:''}" /></div>
      <div class="form-group"><label class="form-label">Paid (₹)</label>
        <input class="form-input" id="f-paid" type="number" placeholder="0" value="${s?s.paid:'0'}" /></div>
    </div>
    <div class="form-group"><label class="form-label">Address</label>
      <input class="form-input" id="f-address" placeholder="City/Area" value="${s?s.address||'':''}" /></div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
      <div class="form-group"><label class="form-label">Parent Name</label>
        <input class="form-input" id="f-pname" placeholder="Father/Mother" value="${s?s.parentName||'':''}" /></div>
      <div class="form-group"><label class="form-label">Parent Phone</label>
        <input class="form-input" id="f-pphone" type="tel" maxlength="10" placeholder="Parent mobile" value="${s?s.parentPhone||'':''}" /></div>
    </div>
  `;
}

function openAddStudent() {
  showModal(`
    <div class="modal-title">➕ Add New Student</div>
    ${studentForm(null)}
    <div class="btn-row">
      <button class="btn btn-secondary" onclick="closeModal()">Cancel</button>
      <button class="btn btn-primary" onclick="saveNewStudent()">Save & WhatsApp</button>
    </div>
  `);
}

function openEditStudent(id) {
  const s = getStudentById(id);
  if (!s) return;
  showModal(`
    <div class="modal-title">✏️ Edit Student</div>
    ${studentForm(s)}
    <div class="btn-row">
      <button class="btn btn-secondary" onclick="closeModal()">Cancel</button>
      <button class="btn btn-primary" onclick="saveEditStudent(${id})">Update</button>
    </div>
  `);
}

function saveNewStudent() {
  const name = (document.getElementById('f-name')?.value||'').trim();
  const phone = (document.getElementById('f-phone')?.value||'').trim();
  if (!name) { showToast('⚠️ Please enter student name'); return; }
  if (!phone || phone.length < 10) { showToast('⚠️ Enter valid 10-digit phone'); return; }

  const batchId = parseInt(document.getElementById('f-batch')?.value);
  const batch = getBatchById(batchId);
  const student = {
    id: ++state.nextStudentId,
    name,
    phone,
    standard: document.getElementById('f-std')?.value || '11',
    batch: batchId,
    subject: document.getElementById('f-subj')?.value || 'Commerce',
    fees: parseInt(document.getElementById('f-fees')?.value) || 0,
    paid: parseInt(document.getElementById('f-paid')?.value) || 0,
    rollNo: String(state.students.length + 1).padStart(3,'0'),
    joinDate: todayISO(),
    address: (document.getElementById('f-address')?.value||'').trim(),
    parentName: (document.getElementById('f-pname')?.value||'').trim(),
    parentPhone: (document.getElementById('f-pphone')?.value||'').trim(),
  };

  state.students.push(student);
  if (batch && !batch.students.includes(student.id)) batch.students.push(student.id);
  saveData();

  const welcomeMsg = `🎉 Welcome to Parikh Commerce Classes, Nadiad!\n\nDear ${name},\n\nYou have been successfully enrolled! 📚\n\n✅ Batch: ${batch?.name||'-'}\n⏰ Time: ${batch?.time||'-'}\n📖 Subject: ${student.subject}\n🆔 Roll No: ${student.rollNo}\n\nWe look forward to your bright future! 🌟\n\n— Parikh Commerce Classes, Nadiad`;

  closeModal();
  showToast('✅ Student added successfully!');

  setTimeout(() => {
    if (confirm(`Send WhatsApp welcome message to ${name}?`)) {
      window.open(waURL(phone, welcomeMsg), '_blank');
    }
  }, 300);
}

function saveEditStudent(id) {
  const s = getStudentById(id);
  if (!s) return;
  const oldBatch = s.batch;
  s.name = (document.getElementById('f-name')?.value||'').trim() || s.name;
  s.phone = (document.getElementById('f-phone')?.value||'').trim() || s.phone;
  s.standard = document.getElementById('f-std')?.value || s.standard;
  s.batch = parseInt(document.getElementById('f-batch')?.value) || s.batch;
  s.subject = document.getElementById('f-subj')?.value || s.subject;
  s.fees = parseInt(document.getElementById('f-fees')?.value) || s.fees;
  s.paid = parseInt(document.getElementById('f-paid')?.value);
  s.address = (document.getElementById('f-address')?.value||'').trim();
  s.parentName = (document.getElementById('f-pname')?.value||'').trim();
  s.parentPhone = (document.getElementById('f-pphone')?.value||'').trim();
  if (oldBatch !== s.batch) {
    const ob = getBatchById(oldBatch);
    if (ob) ob.students = ob.students.filter(sid=>sid!==id);
    const nb = getBatchById(s.batch);
    if (nb && !nb.students.includes(id)) nb.students.push(id);
  }
  saveData();
  closeModal();
  showToast('✅ Student updated!');
}

function deleteStudent(id) {
  const s = getStudentById(id);
  if (!s) return;
  if (!confirm(`Delete ${s.name}? This cannot be undone.`)) return;
  state.students = state.students.filter(st=>st.id!==id);
  state.batches.forEach(b => { b.students = b.students.filter(sid=>sid!==id); });
  saveData();
  showToast('🗑️ Student deleted');
  render();
}

function sendWAStudent(idStr) {
  const s = getStudentById(parseInt(idStr)||idStr);
  if (!s) return;
  const msg = `Hello ${s.name}! 👋\nThis is Parikh Commerce Classes, Nadiad.\n\nHope you are doing well with your ${s.subject} studies! 📚\n\nPlease contact us if you have any queries.\n\n— Parikh Commerce Classes`;
  window.open(waURL(s.phone, msg), '_blank');
}
