// ===== BATCHES MODULE =====

function renderBatches() {
  if (!state.batches.length) return `<div class="empty-state"><div class="empty-icon">📋</div><div class="empty-text">No batches yet. Tap + to add one.</div></div>`;

  return state.batches.map(b => {
    const studs = b.students.map(id=>getStudentById(id)).filter(Boolean);
    const maxCap = 40;
    const pct = Math.min(100, Math.round(studs.length/maxCap*100));
    const chips = studs.slice(0,5).map(s=>`<span class="chip">${s.name.split(' ')[0]}</span>`).join('');
    const extra = studs.length > 5 ? `<span class="chip">+${studs.length-5} more</span>` : '';

    return `<div class="batch-card">
      <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:8px">
        <div>
          <div class="batch-name">${b.name}</div>
          <div class="batch-time">⏰ ${b.time}</div>
          <div class="batch-time">📚 ${b.subject}</div>
        </div>
        <div style="display:flex;gap:6px">
          <button class="btn-icon btn-wa" onclick="openBatchWA(${b.id})" title="WhatsApp">💬</button>
          <button class="btn-icon btn-edit" onclick="openEditBatch(${b.id})" title="Edit">✏️</button>
          <button class="btn-icon btn-del" onclick="deleteBatch(${b.id})" title="Delete">🗑️</button>
        </div>
      </div>
      <div style="font-size:12px;color:#64748b">${studs.length} / ${maxCap} students (${pct}%)</div>
      <div class="progress-bar"><div class="progress-fill" style="width:${pct}%;background:#1a56db"></div></div>
      <div style="flex-wrap:wrap;display:flex;margin-top:6px">${chips}${extra}</div>
      ${b.waLink
        ? `<a href="${b.waLink}" target="_blank" class="btn-wa-full" style="text-decoration:none;font-size:13px;padding:10px;margin-top:10px">💬 Open ${b.name} WhatsApp Group</a>`
        : `<div style="margin-top:8px;font-size:12px;color:#94a3b8">No WhatsApp group linked — <span style="color:#1a56db;cursor:pointer" onclick="openBatchWA(${b.id})">Add group link</span></div>`}
    </div>`;
  }).join('') + '<div style="height:10px"></div>';
}

function batchForm(b) {
  const days = ['Mon','Tue','Wed','Thu','Fri','Sat','Sun'];
  const selDays = b ? (b.days||[]) : ['Mon','Wed','Fri'];
  return `
    <div class="form-group"><label class="form-label">Batch Name *</label>
      <input class="form-input" id="b-name" placeholder="e.g. Vaish Batch" value="${b?b.name:''}" /></div>
    <div class="form-group"><label class="form-label">Timing</label>
      <input class="form-input" id="b-time" placeholder="e.g. 4:00 PM - 6:00 PM" value="${b?b.time:''}" /></div>
    <div class="form-group"><label class="form-label">Subject</label>
      <select class="form-input" id="b-subj">${SUBJECTS.map(s=>`<option value="${s}" ${b&&b.subject===s?'selected':''}>${s}</option>`).join('')}</select></div>
    <div class="form-group"><label class="form-label">Class Days</label>
      <div style="display:flex;gap:6px;flex-wrap:wrap">
        ${days.map(d=>`<label style="display:flex;align-items:center;gap:4px;font-size:13px;cursor:pointer">
          <input type="checkbox" id="day-${d}" ${selDays.includes(d)?'checked':''} /> ${d}
        </label>`).join('')}
      </div>
    </div>
    <div class="form-group"><label class="form-label">WhatsApp Group Link</label>
      <input class="form-input" id="b-wa" placeholder="https://chat.whatsapp.com/..." value="${b?b.waLink||'':''}" /></div>
  `;
}

function openAddBatch() {
  showModal(`
    <div class="modal-title">➕ New Batch</div>
    ${batchForm(null)}
    <div class="btn-row">
      <button class="btn btn-secondary" onclick="closeModal()">Cancel</button>
      <button class="btn btn-primary" onclick="saveNewBatch()">Create Batch</button>
    </div>
  `);
}

function openEditBatch(id) {
  const b = getBatchById(id);
  if (!b) return;
  showModal(`
    <div class="modal-title">✏️ Edit Batch</div>
    ${batchForm(b)}
    <div class="btn-row">
      <button class="btn btn-secondary" onclick="closeModal()">Cancel</button>
      <button class="btn btn-primary" onclick="saveEditBatch(${id})">Update</button>
    </div>
  `);
}

function getSelectedDays() {
  const days = ['Mon','Tue','Wed','Thu','Fri','Sat','Sun'];
  return days.filter(d => document.getElementById('day-'+d)?.checked);
}

function saveNewBatch() {
  const name = (document.getElementById('b-name')?.value||'').trim();
  if (!name) { showToast('⚠️ Enter batch name'); return; }
  state.batches.push({
    id: ++state.nextBatchId,
    name,
    time: (document.getElementById('b-time')?.value||'').trim(),
    subject: document.getElementById('b-subj')?.value || 'Commerce',
    days: getSelectedDays(),
    students: [],
    waLink: (document.getElementById('b-wa')?.value||'').trim(),
  });
  saveData();
  closeModal();
  showToast('✅ Batch created!');
}

function saveEditBatch(id) {
  const b = getBatchById(id);
  if (!b) return;
  b.name = (document.getElementById('b-name')?.value||'').trim() || b.name;
  b.time = (document.getElementById('b-time')?.value||'').trim();
  b.subject = document.getElementById('b-subj')?.value || b.subject;
  b.days = getSelectedDays();
  b.waLink = (document.getElementById('b-wa')?.value||'').trim();
  saveData();
  closeModal();
  showToast('✅ Batch updated!');
}

function deleteBatch(id) {
  const b = getBatchById(id);
  if (!b) return;
  if (b.students.length > 0) { showToast('⚠️ Move students out before deleting batch'); return; }
  if (!confirm(`Delete batch "${b.name}"?`)) return;
  state.batches = state.batches.filter(bt=>bt.id!==id);
  saveData();
  showToast('🗑️ Batch deleted');
  render();
}

function openBatchWA(id) {
  const b = getBatchById(id);
  if (!b) return;
  const studs = b.students.map(sid=>getStudentById(sid)).filter(Boolean);
  const studList = studs.slice(0,6).map(s=>
    `<button class="btn-wa-full" style="font-size:12px;padding:9px;margin-top:5px" onclick="sendBatchMsg('${s.phone}','${s.name}')">💬 Send to ${s.name.split(' ')[0]}</button>`
  ).join('');

  showModal(`
    <div class="modal-title">💬 ${b.name} WhatsApp</div>
    <div class="form-group">
      <label class="form-label">Group Invite Link</label>
      <input class="form-input" id="bwa-link" value="${b.waLink||''}" placeholder="https://chat.whatsapp.com/..." />
      <div style="font-size:11px;color:#64748b;margin-top:4px">In WhatsApp: Open group → Invite via link → Copy</div>
    </div>
    <div class="btn-row">
      <button class="btn btn-secondary btn-full" onclick="saveBatchLink(${id})">Save Link</button>
      ${b.waLink?`<a href="${b.waLink}" target="_blank" class="btn btn-green" style="text-decoration:none;display:flex;align-items:center;justify-content:center;flex:1">Open Group</a>`:''}
    </div>
    <div class="divider" style="margin:14px 0"></div>
    <div style="font-size:13px;font-weight:600;margin-bottom:8px">Send Batch Message</div>
    <textarea class="form-input" id="bwa-msg" rows="4">Class reminder for ${b.name}! 📚
Tomorrow: ${b.subject} class at ${b.time}
Please be on time and bring your notes.

— Parikh Commerce Classes, Nadiad</textarea>
    ${studList}
    ${studs.length>6?`<div style="text-align:center;font-size:12px;color:#94a3b8;margin-top:6px">+${studs.length-6} more students</div>`:''}
    <button class="btn btn-secondary btn-full" style="margin-top:12px" onclick="closeModal()">Close</button>
  `);
}

function saveBatchLink(id) {
  const b = getBatchById(id);
  if (!b) return;
  b.waLink = (document.getElementById('bwa-link')?.value||'').trim();
  saveData();
  showToast('✅ Group link saved!');
}

function sendBatchMsg(phone, name) {
  const msg = document.getElementById('bwa-msg')?.value || '';
  if (!msg.trim()) { showToast('⚠️ Enter a message first'); return; }
  window.open(waURL(phone, msg), '_blank');
}
