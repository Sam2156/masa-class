// ===== MAIN APP =====

function showTab(tab) {
  state.currentTab = tab;
  document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
  const navBtn = document.getElementById('nav-' + tab);
  if (navBtn) navBtn.classList.add('active');
  render();
}

function render() {
  removeFab();
  const c = document.getElementById('app-content');
  const ta = document.getElementById('topbar-actions');
  ta.innerHTML = '';
  switch(state.currentTab) {
    case 'dashboard':   c.innerHTML = renderDashboard(); break;
    case 'students':    c.innerHTML = renderStudents(); addFab(openAddStudent); break;
    case 'batches':     c.innerHTML = renderBatches(); addFab(openAddBatch); break;
    case 'fees':        c.innerHTML = renderFees(); break;
    case 'attendance':  c.innerHTML = renderAttendance(); break;
    case 'whatsapp':    c.innerHTML = renderWhatsApp(); break;
  }
}

function removeFab() {
  const f = document.getElementById('main-fab');
  if (f) f.remove();
}

function addFab(fn) {
  const btn = document.createElement('button');
  btn.className = 'fab';
  btn.id = 'main-fab';
  btn.innerHTML = '+';
  btn.onclick = fn;
  document.getElementById('app').appendChild(btn);
}

function showModal(html) {
  const overlay = document.getElementById('modal-overlay');
  const content = document.getElementById('modal-content');
  content.innerHTML = html;
  overlay.style.display = 'flex';
  setTimeout(() => overlay.style.opacity = '1', 10);
}

function closeModal() {
  const overlay = document.getElementById('modal-overlay');
  overlay.style.display = 'none';
  render();
}

function handleOverlayClick(e) {
  if (e.target === document.getElementById('modal-overlay')) closeModal();
}

function showToast(msg, duration=2500) {
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.classList.add('show');
  setTimeout(() => t.classList.remove('show'), duration);
}

// ===== DASHBOARD =====
function renderDashboard() {
  const total = state.students.length;
  const totalFees = state.students.reduce((a,s)=>a+(s.fees||0),0);
  const paidFees = state.students.reduce((a,s)=>a+(s.paid||0),0);
  const pending = totalFees - paidFees;
  const defaulters = state.students.filter(s=>pendingFee(s)>0).length;
  const today = new Date().toLocaleDateString('en-IN',{weekday:'long',day:'numeric',month:'long',year:'numeric'});

  const recentStudents = [...state.students].reverse().slice(0,4).map((s,i) => {
    const av = getAvatarColors(s.name);
    return `<div class="card" style="padding:12px;margin-bottom:8px">
      <div class="student-row">
        <div class="avatar" style="width:38px;height:38px;font-size:13px;background:${av.bg};color:${av.text}">${getInitials(s.name)}</div>
        <div class="student-info">
          <div class="student-name">${s.name}</div>
          <div class="student-meta">${getBatchName(s.batch)} · Std ${s.standard}</div>
        </div>
        <span class="badge ${pendingFee(s)>0?'badge-red':'badge-green'}">${pendingFee(s)>0?'Due':'Paid'}</span>
      </div>
    </div>`;
  }).join('');

  const batchRows = state.batches.map(b =>
    `<div class="report-row">
      <span style="font-size:14px">${b.name}</span>
      <div style="display:flex;gap:6px;align-items:center">
        <span class="badge badge-blue">${b.students.length} students</span>
        <span style="font-size:11px;color:#64748b">${b.time}</span>
      </div>
    </div>`
  ).join('');

  return `
    <div style="font-size:12px;color:#64748b;margin-bottom:12px;background:#fff;padding:8px 12px;border-radius:10px">${today}</div>
    <div class="stat-grid">
      <div class="stat stat-blue"><div class="stat-val">${total}</div><div class="stat-lbl">Total Students</div></div>
      <div class="stat stat-green"><div class="stat-val">${state.batches.length}</div><div class="stat-lbl">Active Batches</div></div>
      <div class="stat stat-green"><div class="stat-val">${formatCurrency(paidFees)}</div><div class="stat-lbl">Fees Collected</div></div>
      <div class="stat stat-red"><div class="stat-val">${formatCurrency(pending)}</div><div class="stat-lbl">Pending Fees</div></div>
    </div>
    <div class="card">
      <div class="card-title">📊 Batch Overview</div>
      ${batchRows || '<div style="color:#94a3b8;font-size:13px">No batches yet</div>'}
    </div>
    <div class="section-title">Recent Students</div>
    ${recentStudents || '<div class="empty-state"><div class="empty-icon">👨‍🎓</div><div class="empty-text">No students yet. Tap Students to add!</div></div>'}
    <div style="height:10px"></div>
  `;
}
