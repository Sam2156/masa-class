// ===== DATA LAYER =====
const SUBJECTS = ['Accounts','Economics','Commerce','Business Studies','Maths','English','Statistics'];
const STANDARDS = ['11','12','FY','SY','TY'];
const COLORS_BG = ['#e8f0fe','#def7ec','#fce8d5','#fde8e8','#fef3c7','#ede9fe','#fce7f3'];
const COLORS_TEXT = ['#1a56db','#0e9f6e','#c2610a','#e02424','#d97706','#7c3aed','#be185d'];

let state = {
  students: [],
  batches: [
    {id:1, name:'Morning Batch', time:'7:00 AM - 9:00 AM', subject:'Accounts', students:[], waLink:'', days:['Mon','Wed','Fri']},
    {id:2, name:'Vaish Batch', time:'4:00 PM - 6:00 PM', subject:'Commerce', students:[], waLink:'', days:['Mon','Tue','Wed','Thu','Fri']},
    {id:3, name:'Evening Batch', time:'6:30 PM - 8:30 PM', subject:'Accounts', students:[], waLink:'', days:['Mon','Wed','Fri','Sat']},
  ],
  attendance: {},
  currentTab: 'dashboard',
  filterBatch: 'all',
  searchQ: '',
  nextStudentId: 100,
  nextBatchId: 10,
};

function loadData() {
  try {
    const saved = localStorage.getItem('pcc_v2');
    if (saved) {
      const d = JSON.parse(saved);
      Object.assign(state, d);
    }
  } catch(e) { console.log('Load error', e); }
}

function saveData() {
  try {
    localStorage.setItem('pcc_v2', JSON.stringify({
      students: state.students,
      batches: state.batches,
      attendance: state.attendance,
      nextStudentId: state.nextStudentId,
      nextBatchId: state.nextBatchId,
    }));
  } catch(e) { console.log('Save error', e); }
}

function seedData() {
  if (state.students.length > 0) return;
  state.students = [
    {id:1, name:'Riya Patel', phone:'9876543210', batch:2, subject:'Commerce', fees:2500, paid:2500, rollNo:'001', joinDate:'2025-06-01', standard:'11', address:'Nadiad', parentName:'Rajesh Patel', parentPhone:'9876543200'},
    {id:2, name:'Arjun Shah', phone:'9765432109', batch:1, subject:'Accounts', fees:3000, paid:1500, rollNo:'002', joinDate:'2025-06-01', standard:'12', address:'Nadiad', parentName:'Sunil Shah', parentPhone:'9765432100'},
    {id:3, name:'Priya Modi', phone:'9654321098', batch:2, subject:'Commerce', fees:2500, paid:2500, rollNo:'003', joinDate:'2025-06-15', standard:'11', address:'Nadiad', parentName:'Nitin Modi', parentPhone:'9654321000'},
    {id:4, name:'Kush Desai', phone:'9543210987', batch:3, subject:'Accounts', fees:3000, paid:0, rollNo:'004', joinDate:'2025-07-01', standard:'12', address:'Anand', parentName:'Mahesh Desai', parentPhone:'9543210900'},
    {id:5, name:'Nisha Trivedi', phone:'9432109876', batch:2, subject:'Commerce', fees:2500, paid:1000, rollNo:'005', joinDate:'2025-07-10', standard:'11', address:'Nadiad', parentName:'Suresh Trivedi', parentPhone:'9432109800'},
  ];
  state.students.forEach(s => {
    const b = state.batches.find(b=>b.id===s.batch);
    if (b && !b.students.includes(s.id)) b.students.push(s.id);
  });
  state.nextStudentId = 10;
  saveData();
}

function getStudentById(id) { return state.students.find(s=>s.id===id); }
function getBatchById(id) { return state.batches.find(b=>b.id===id); }
function getBatchName(id) { const b = getBatchById(id); return b ? b.name : 'Unknown'; }
function pendingFee(s) { return Math.max(0, (s.fees||0) - (s.paid||0)); }
function getInitials(name) { return (name||'').split(' ').map(w=>w[0]).join('').toUpperCase().slice(0,2) || '?'; }
function getAvatarColors(name) {
  const idx = (name||'A').charCodeAt(0) % COLORS_BG.length;
  return { bg: COLORS_BG[idx], text: COLORS_TEXT[idx] };
}
function waURL(phone, msg) {
  const p = (phone||'').replace(/\D/g,'');
  const fullPhone = p.startsWith('91') ? p : '91'+p;
  return `https://wa.me/${fullPhone}?text=${encodeURIComponent(msg)}`;
}
function formatCurrency(n) { return '₹' + (n||0).toLocaleString('en-IN'); }
function formatDate(d) { return d ? new Date(d).toLocaleDateString('en-IN',{day:'2-digit',month:'short',year:'numeric'}) : '-'; }
function todayISO() { return new Date().toISOString().split('T')[0]; }

loadData();
seedData();
