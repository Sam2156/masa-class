==============================================
  PARIKH COMMERCE CLASSES - APP INSTALLATION
==============================================

METHOD 1: INSTANT (No installation needed)
------------------------------------------
1. Copy all these files to a USB drive or Google Drive
2. Upload them to a free host like:
   - netlify.com (drag & drop the folder → free link!)
   - GitHub Pages (free)
3. Open the link in Chrome on Android
4. Chrome will show "Add to Home Screen" banner
5. Tap it → App installed on your phone! ✅

METHOD 2: Convert to APK using PWABuilder
-----------------------------------------
1. First host the app online (see Method 1)
2. Go to: https://www.pwabuilder.com
3. Paste your app URL
4. Click "Build" → Android → Download APK
5. Install the APK on your Android phone

METHOD 3: Local WiFi (no internet needed)
-----------------------------------------
1. Install Node.js on your PC
2. Open terminal/cmd in this folder
3. Run: npx serve .
4. It shows a URL like http://192.168.1.X:3000
5. Open that URL on your phone (same WiFi)
6. Add to Home Screen from Chrome!

==============================================
  FEATURES INCLUDED
==============================================
✅ Student Management (Add/Edit/Delete)
✅ Batch Management (Morning/Vaish/Evening)
✅ Fee Tracking (Collect, Reminders, Receipts)
✅ Attendance (Mark Present/Absent per day)
✅ WhatsApp Integration:
   - Welcome message when student added
   - Fee reminder via WhatsApp
   - Fee receipt via WhatsApp
   - Batch announcement broadcast
   - Absent notice to parents
   - WhatsApp group links per batch
✅ Works Offline (after first load)
✅ Data saved on device (localStorage)

==============================================
  WHATSAPP GROUP NOTE
==============================================
WhatsApp does NOT allow any app to auto-create
groups (this is WhatsApp's own restriction).
Instead:
1. Create the group manually in WhatsApp
2. Get the group invite link
3. Paste it in the Batches tab
4. One-tap to open the group anytime!
==============================================
